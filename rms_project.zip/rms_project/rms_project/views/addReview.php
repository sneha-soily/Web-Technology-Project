<!DOCTYPE html>
<html lang="">
<head>
    <title>Review Page</title>
    <link rel="stylesheet" href="../views/css/history.css">

</head>
<body>

<form method="post" action="../models/index.php">

    <div style="text-align: center;">
        <br><br>
            <center>
        <table width="500px">
            <tr>
                <td>
                    <table width="500px">
                        <tr>
                            <td>
                                <h3><b>Customer Review</b></h3>
                            </td>
                            <td class="order">
                                <a href="Dashboard.php">Home</a>
                                <a href="History.php">Update/Delete Review</a>
                                <a href="../views/History.php">Review</a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <tr>
                <td colspan="2">
                    <fieldset>
                        <legend>Review</legend>
                        <table>
                            <tr>
                                <td>Customer Name</td>
                                <td><input type="text" name="cname"></td>

                            </tr>
                            <tr>
                                <td colspan="2">
                                    <hr>
                                </td>
                            </tr>
                            <tr>
                                <td>Itemname</td>
                                <td><input type="text" name="itemname"></td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <hr>
                                </td>
                            </tr>

                            <tr>
                                <td>Review</td>
                                <td><input type="text" name="review"></td>
                            </tr>
                            <tr>
                                <td><input type="submit" name="submit" value="Submit"></td>
                            </tr>

                        </table>
                </td>
            </tr>

        </table>
        </center>
    </div>

</form>

</body>
</html>
<?php include '../views/footer.php' ?>