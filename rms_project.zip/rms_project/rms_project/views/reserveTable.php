<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Reserve Table</title>
	<link rel="stylesheet" href="../views/css/history.css">
</head>
<body>
	<h1 style="text-align: center">Reserve Table</h1>
	<br><br>
<fieldset>
	<legend><h3>Please provide your reserve time</h3></legend>

 	<form action="Forgetpass.php" method="POST" novalidate>
		
		
		<label for="name">Name</label>
		<input type="text" name="name" id="name" required>

		<br><br>

		<label for="email">Email</label>
		<input type="text" name="email" id="email" required>

		<br><br>

		<label for="Phone">Phone </label>
		<input type="text" name="Phone" id="Phone" required>
		
		<br><br>

		<label for="time">Time</label>
		<input type="time" name="time" id="time" required>
		
		<br><br>

		<input type="submit" name="submit" value="submit">
		<br><br>
	</form>
	
			
	<a href="Dashboard.php">Go Back</a>
</fieldset>
	<br><br>
	<?php include('footer.php');?>
	</body>

</html>
