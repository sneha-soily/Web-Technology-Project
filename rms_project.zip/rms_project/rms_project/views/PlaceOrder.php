
<!DOCTYPE html>
<html>
<head>
	<title>Order Page</title>
	<link rel="stylesheet" href="../views/css/history.css">


</head>
<body>
	<form name="regform" onsubmit="return validateForm();" method="post" action="../models/PlaceOrderdb.php">
<center>
	<br><br>
    <table  width="500px">
	    <tr>
            <td>
                <table width="500px">
                    <tr>
						<td>
                <h1><b>Place Order</b></h1>
            </td>
            <div class="order">
            	<a href="Dashboard.php">Home</a>
                <a href="OrderHistory.php">Update/Delete Order</a>
                <a href="OrderHistory.php">Customer Order Added Table</a>
         
            </div>
                    </tr>
                    </table>
            </td>
        </tr>
        
        <tr>
            <td colspan="2">
			<fieldset>
			<legend><b>FOOD ITEMS<b></legend>
			<table>
			<tr>
					<td>Customer Name</td>
					<td><input type="text" name="cname" > </td>
					<span style= "color:red" id = "alert"></span>
					
				</tr>
				<tr>
                   <td colspan="2"><hr></td> 
                </tr>
			   <tr>
					<td>Customer Phone Number</td>
					<td><input type="text" name="cnumber"> </td>
					
				</tr>
				<tr>
                   <td colspan="2"><hr></td> 
                </tr>
				<tr>
					<td>Itemname</td>
					<td><input type="text" name="itemname"> </td>
					<span style= "color:red" id = "alert1"></span>
					
				</tr>
				<tr>
                   <td colspan="2"><hr></td> 
                </tr>
				
				<tr>
					<td>Quantity</td>
					<td><input type="number" name="quantity"></td>
					<span style= "color:red" id = "alert2"></span>
				</tr>
				<tr>
                   <td colspan="2"><hr></td> 
                </tr>
				
				<tr>
					<td>Price</td>
					<td><input type="text" name="price"></td>
				</tr>
				<tr>
                   <td colspan="2"><hr></td> 
                </tr>
			
				
                <tr>
                    <td colspan="2">
					<fieldset>
					<legend>Drinks</legend>
                        <input type="radio" name="drinks" value="CocaCola"> CokaCola
                        <input type="radio" name="drinks" value="7up"> 7up
                        <input type="radio" name="drinks" value="Pepsi"> Pepsi
                    </fieldset>
					<hr>
					</td>
                </tr>

				<tr>
					<td><input type="submit" name="submit" value="Submit"> <input type="reset" name="reset" value="Reset"></td>
				</tr>

			</table>
            </td>
        </tr>
       
    </table>
    </center>
		
	</form>
	<script>
	function validatename(){

    var ptrn = /^([^0-9]*)$/;
    var name = document.getElementById("cname");
    if(name.value ==""){
    document.getElementById("alert").innerHTML = "*Name can't be empty";
    
    }else if(!ptrn.test(document.regform.fname.value)){
        document.getElementById("alert").innerHTML = "*Name can't have digit";

    } else if(name.value.length<2){
        document.getElementById("alert").innerHTML = "*Name can't have less than 2 two digits";

    }else if(name.value.length>20){
        document.getElementById("alert").innerHTML = "*Name can't be more than 20 two digits";

    }else{
        document.getElementById("alert").innerHTML = "";
       
    } 

} document.regform.fname.addEventListener("keyup",validatename);

function itemName() {
	var itemname = document.getElementById('itemname');
	if(itemname.value==""){
		document.getElementById("alert").innerHTML = "*Item name can't be empty";
	}

} document.regform.itemname.addEventListener("keyup",itemName);

function quantityValid() {
	var quantity = document.getElementById('quantity');
	if(quantity.value==""){
		document.getElementById("alert2").innerHTML = "*Please provide quantity";
	}

} document.regform.quantity.addEventListener("keyup",quantityValid);

function validateForm() {

    let x = document.forms["regform"]["cname"].value;
    let xx = document.forms["regform"]["itemname"].value;
	let xxx = document.forms["regform"]["quantity"].value;
        if (x == ""){
        document.getElementById("alert").innerHTML = "*Name must be filled out";
        	return false}
        else if(xx ==""){
            document.getElementById("alert1").innerHTML = "*Item name can't be empty";
            return false;}
        else if(xxx ==""){
            document.getElementById("alert2").innerHTML = "*Please provide quantity";
            return false;}
   
  }
	</script>
</body>
</html>
<?php include '../views/footer.php' ?>