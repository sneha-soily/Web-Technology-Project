
<?php
    include '../models/order.php';

    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Display History</title>
    <link rel="stylesheet" href="../views/css/history.css">
</head>
<body>
<center>
    <br><br>
    <div class="order">
        <td>
            <a href="../views/Dashboard.php">Home</a>
            <a href="../views/PlaceOrder.php">Place Order</a> 
            <a href="../views/OrderHistory.php">Order History</a>
        </td>
    </div>
<br><br>
<div class="container">
    
<table class="table">
    <h1 class="heading">Customer Order List</h1>
  <thead>
    <tr>
      <th scope="col">Serial_Id</th>
      <th scope="col">Customer_Name</th>
      <th scope="col">Phone</th>
      <th scope="col">Itemname</th>
      <th scope="col">Quantity</th>
      <th scope="col">Price</th>
      <th scope="col">Drinks</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $sql = "Select * from `converttable`";
    $result=mysqli_query($con,$sql);
    if ($result) {
        while ($row= mysqli_fetch_assoc($result)) {
              $Serial_Id=$row['Serial_Id'];
              $cname=$row['Customer_Name'];
              $cnumber=$row['Phone'];
              $itemname=$row['Itemname'];
              $quantity=$row['Quantity'];
              $price=$row['Price'];
              $drinks=$row['Drinks'];
            
            echo '<tr>
              <th scope="row">'.$Serial_Id.'</th>
              <td>'.$cname.'</td>
              <td>'.$cnumber.'</td>
              <td>'.$itemname.'</td>
              <td>'.$quantity.'</td>
              <td>'.$price.'</td>
              <td>'.$drinks.'</td>
              <td>
                    <button><a href="UpdateOrder.php?updateid='.$Serial_Id.'">Update</a></button>
                    <button><a href="CancelOrder.php?deleteid='.$Serial_Id.'">Delete</a></button>
              </td>
            </tr>';
        }
    }


    ?>

  </tbody>
</table>


    </div>


</center>
</body>
</html>