
<?php
    include '../models/order.php';

    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Customer Review History</title>
    <link rel="stylesheet" href="../views/css/history.css">
</head>
<body>
    <center>
        <br><br>
    <div class="order">
        <td align="Right">
            <a href="../views/Dashboard.php">Home</a>
            <a href="../views/addReview.php">Add Review</a> 
            <a href="../views/History.php">Customer Review</a>  
        </td>
    </div>
<br><br>
<div class="container">
    
<table class="table">
    <h1 class="heading">Customer Review List</h1>
  <thead>
    <tr>
      <th scope="col">Serial_Id</th>
      <th scope="col">Customer Name</th>
      <th scope="col">Itemname</th>
      <th scope="col">Review</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $sql = "Select * from `reviewtable`";
    $result=mysqli_query($con,$sql);
    if ($result) {
        while ($row= mysqli_fetch_assoc($result)) {
              $Serial_Id=$row['Serial_Id'];
              $cname=$row['Customer_Name'];
              $itemname=$row['Itemname'];
              $review=$row['Review'];
            
            echo '<tr>
              <th scope="row">'.$Serial_Id.'</th>
              <td>'.$cname.'</td>
              <td>'.$itemname.'</td>
              <td>'.$review.'</td>
              <td>
                    <button><a href="updateReview.php?updateid='.$Serial_Id.'">Update</a></button>
                    <button><a href="deleteReview.php?deleteid='.$Serial_Id.'">Delete</a></button>
              </td>
            </tr>';
        }
    }


    ?>

  </tbody>
</table>


    </div>


</center>
</body>
</html>