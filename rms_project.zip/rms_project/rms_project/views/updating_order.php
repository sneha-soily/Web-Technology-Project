<?php 
session_start();
include '../models/order.php';
$Serial_Id = $_SESSION['$Serial_Id'];
if(isset($_POST['submit']))
{

  $cname=$_POST['cname'];
  $cnumber=$_POST['cnumber'];
  $itemname=$_POST['itemname'];
  $quantity=$_POST['quantity'];
  $price=$_POST['price'];
  $drinks=$_POST['drinks'];

  $sql=$sql="update `converttable` set Customer_Name='$cname', Phone='$cnumber', Itemname='$itemname', Quantity='$quantity',Price='$price',Drinks='$drinks' where Serial_Id=$Serial_Id";
      $result=mysqli_query($con,$sql);
 

  if($result)
  {
    echo "Data updated successfully";
    header('location: OrderHistory.php');
  }
  else
  {
    die(mysqli_error($con));
  }


}
?>
