<?php 
session_start();
include '../models/order.php';
$Serial_Id = $_SESSION['$Serial_Id'];
if(isset($_POST['submit']))
{

  $cname=$_POST['cname'];
  $itemname=$_POST['itemname'];
  $review=$_POST['review'];

  $sql=$sql="update `reviewtable` set Customer_Name='$cname',Itemname='$itemname', Review='$review' where Serial_Id=$Serial_Id";
      $result=mysqli_query($con,$sql);
 

  if($result)
  {
    echo "Data updated successfully";
    header('location: History.php');
  }
  else
  {
    die(mysqli_error($con));
  }


}
?>