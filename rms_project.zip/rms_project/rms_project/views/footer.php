<footer>
	<h3 align="Center"><b>Restaurant Management System Copyright © 2022 - <?php echo date("Y"); ?></b></h3>
</footer>
</body>