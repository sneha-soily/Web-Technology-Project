
function validatename(){

    var ptrn = /^([^0-9]*)$/;
    var name = document.getElementById("cname");
    if(name.value ==""){
    document.getElementById("alert").innerHTML = "*Name can't be empty";
    
    }else if(!ptrn.test(document.regform.fname.value)){
        document.getElementById("alert").innerHTML = "*Name can't have digit";

    } else if(name.value.length<2){
        document.getElementById("alert").innerHTML = "*Name can't have less than 2 two digits";

    }else if(name.value.length>20){
        document.getElementById("alert").innerHTML = "*Name can't be more than 20 two digits";

    }else{
        document.getElementById("alert").innerHTML = "";
       
    } 

} document.regform.fname.addEventListener("keyup",validatename);

function itemName() {
	var itemname = document.getElementById('itemname');
	if(itemname.value==""){
		document.getElementById("alert").innerHTML = "*Item name can't be empty";
	}

} document.regform.itemname.addEventListener("keyup",itemName);

function validateForm() {

    let x = document.forms["regform"]["cname"].value;
    let xx = document.forms["regform"]["itemname"].value;

        if (x == ""){
        document.getElementById("alert").innerHTML = "*Name must be filled out";
        return false}
        else if(xx ==""){
            document.getElementById("alert1").innerHTML = "*Item name can't be empty";
            return false;}
   
  }