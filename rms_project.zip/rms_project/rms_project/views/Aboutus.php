<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

  <a href="Dashboard.php">Back</a>

  
  <fieldset >
  <legend><h1 >About Us Page</h1></legend>
  <p>Are you hungry? Did you have a long and stressful day? Interested in getting a cheesy pizza delivered to your office or looking to avoid the weekly shop? Then this restuarant management system in Bangladesh is the right destination for you! offers you a long and detailed list of the best restaurants and shops near you to help make your everyday easier. Our online food delivery service has it all, whether you fancy a juicy burger from Takeout, fresh sushi from Samdado or peri peri chicken from Nando's,Bangladesh has over 2000 restaurants available</p>
  </fieldset>
<center>
<h2 style="text-align:center">Our Team</h2>
        <br><br>

        <h2>Sumaiya Malik</h2>
        <p class="title">Admin</p>
        <p>Some text that describes me.</p>
        <p>sumaiya12@example.com</p>
        <p><button class="button">Contact</button></p>

        <br><br>

        <h2>Tamim Ishraq</h2>
        <p class="title">Manager</p>
        <p>Some text that describes me.</p>
        <p>mtamim@example.com</p>
        <p><button class="button">Contact</button></p>
        
        <br><br>

        <h2>Sneha Ghosh</h2>
        <p class="title">Management</p>
        <p>Some text that describes me.</p>
        <p>sneha@example.com</p>
        <p><button class="button">Contact</button></p>

        <br><br>

        <h2>Sabit Hasan</h2>
        <p class="title">Decoration and designing</p>
        <p>Some text that describes me.</p>
        <p>sabit@example.com</p>
        <p><button class="button">Contact</button></p>

</center>
</body>
</html>
