<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Find Near Restaurant</title>
</head>
<body>

	<div>
		<h2 style="text-align:center;">Find Near Restaurant</h2>
		<p style="text-align:center;"><input type="text" class="form-control" id="live_search" name="Find Near Restaurant " autocomplete="off" placeholder="Search ..."></p>
	</div>
	<div id="searchresult"></div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){

		$("#live_search").keyup(function(){
			var input = $(this).val();
			//alert(input);

			if (input != "") {
				$.ajax({
					url: "livesearch.php",
					method: "POST",
					data:{input:input},

					success:function(data){
						$("#searchresult").html(data);
						$("#searchresult").css("display","block");
					}

				});
			}else{
				$("#searchresult").css("display","none");
			}
		});
	});
</script>
</body>
</html>