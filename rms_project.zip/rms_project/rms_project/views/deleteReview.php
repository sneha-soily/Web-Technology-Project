<?php

	include '../models/order.php';
	if(isset($_GET['deleteid']))
	{
		$Serial_Id=$_GET['deleteid'];
		$sql="DELETE from reviewtable where Serial_Id=$Serial_Id";
		$result=mysqli_query($con,$sql);
		if($result)
		{
			header("location: History.php");
			//echo "Deleted successfully";
		}else
		{
			//die(mysql_error($con));
		}
	}

?>