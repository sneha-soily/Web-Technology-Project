<?php

session_start();
include("../models/connection.php");
include("../models/function.php");


$user_data = check_login($con);

if (!isset($_SESSION['username'])) {
    ?>
    <title>Access Denied</title>
    <br><br>
    <fieldset>
        <h1 style="text-align: center;">Restaurant Management System</h1>
        <br>
        <h1 style="text-align: center;">If you get this page access, then first log in/registration</h1>
        <a href="../views/login.php"><p style="text-align: center;">1. Login Page</p></a>
        <a href="../views/Registration.php"><p style="text-align: center;">2. Registration Page</p></a>
    </fieldset>
    <?php
    include('footer.php');

} else {
    ?>


    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Dashboard</title>
        <link rel="stylesheet" href="../views/css/Dashboard.css">

    </head>
    <body>

    <h1 class="head">Food Nation</h1>
    <div class="nav">
        <ul>
            <li><a href="../views/Dashboard.php">Home</a></li>
            <li><a href="../models/header.php">View Profile</a></li>
            <li><a href="../views/Findrestaurant.php">Near</a></li>
            <li><a href="../views/reserveTable.php">Reserve Table</a></li>
            <li><a href="../views/Showmenu.php">Menu</a></li>
            <li><a href="../views/Paymentsystem.php">Payment</a></li>
            <li><a href="../views/addReview.php">Review</a></li>
            <li><a href="../views/Contactus.php">Contact</a></li>
            <li><a href="../views/Logout.php">Logout</a></li>
        </ul>
    </div>

    <br><br>

    <div class="img">
        <img src="../views/css/Restaurant.jpg">
    </div>

    <br><br>

    <div class="container">
        <div class="row">
            <div class="img">
                <img src="../views/css/Noodles.jpg">
                <h2>Noodles</h2>
            </div>

            <div class="img">
                <img src="../views/css/ChickenBiriyani.jpg">
                <h2>Biriyani</h2>
            </div>

            <div class="img">
                <img src="../views/css/Frenchfry.jpg">
                <h2>French Fry</h2>
            </div>

        </div>

    </div>

    <div class="container">
        <div class="row">
            <div class="img">
                <img src="../views/css/Burger.jpg">
                <h2>Burger</h2>
            </div>

            <div class="img">
                <img src="../views/css/1.jpg">
                <h2>Sandwich</h2>
            </div>

            <div class="img">
                <img src="../views/css/2.jpg">
                <h2>Roll</h2>
            </div>
        </div>

    </div>

    <div class="container">
        <div class="row">
            <div class="img">
                <img src="../views/css/3.jpg">
                <h2>Coffee</h2>
            </div>

            <div class="img">
                <img src="../views/css/4.jpg">
                <h2>Platter</h2>
            </div>

            <div class="img">
                <img src="../views/css/5.jpg">
                <h2>Cooking</h2>
            </div>
        </div>

    </div>

    <div class="container">
        <div class="row">
            <div class="img">
                <img src="../views/css/6.jpg">
                <h2>Pastry</h2>
            </div>

            <div class="img">
                <img src="../views/css/7.jpg">
                <h2>Dessert</h2>
            </div>

            <div class="img">
                <img src="../views/css/8.jpg">
                <h2>Soup</h2>
            </div>
        </div>

    </div>

    <div class="container">
        <div class="row">
            <div class="img">
                <img src="../views/css/9.jpg">
                <h2>Cup Cake</h2>
            </div>

            <div class="img">
                <img src="../views/css/10.jpg">
                <h2>Donut</h2>
            </div>

            <div class="img">
                <img src="../views/css/11.jpg">
                <h2>Juice</h2>
            </div>
        </div>

    </div>

    <br><br>
    <br><br>

    <div class="about">
        <h1>About Us</h1>
        <img src="../views/css/8logo.png">
        <p>
        <h3>|Our email address: admin@100forms.com</h3></p>
        <p>
        <h3>|Conact us: +8801720907331</h3></p>
        <p>
        <h3>|Address: 4 No. Shilpo Plot, Ring Rd, Dhaka 1207</h3></p>
    </div>

    <?php include('footer.php') ?>
    </body>
    </html>

    <?php
}

?>