<?php
session_start();

require_once "../models/connection.php";
include("../views/Login.php");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
}
$sql = "SELECT * FROM 'user_form' WHERE 'username'='$username'and 'password'='$password'";
$con = getConnection();
$searchresult = mysqli_query($con, $sql);
$count = mysqli_num_rows($searchresult);
if ($count > 0) {
    $_SESSION['user'] = $username;
    if (isset($_POST['remember_me']) && $_POST['remember_me'] == 'remembered') {
        setcookie("user", $username, time() + 3600, '/');
    }
    header("Location:../views/Dashboard.php");

}