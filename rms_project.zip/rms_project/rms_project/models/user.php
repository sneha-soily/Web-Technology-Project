<?php

function credentials($username, $password)
{
    $conn = mysqli_connect("localhost", "root", "", "convertdb");
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $stmt = mysqli_stmt_init($conn);
    mysqli_stmt_prepare($stmt, "SELECT username, password FROM user_form WHERE username = ? and password = ?");
    mysqli_stmt_bind_param($stmt, "ss", $username, $password);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    return $result->num_rows === 1;
}

function getConnection()
{
    $conn = mysqli_connect("localhost", "root", "", "convertdb");
    return $conn;
}

?>