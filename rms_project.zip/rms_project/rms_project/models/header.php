<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../views/css/Dashboard.css">
	

</head>
<body>
<div class="nav">
	<ul type="none">	
		<li><a href="../views/Dashboard.php">Home</a></li>

		<li><a href="../views/Changepass.php">Change Password</a></li>

		<li><a href="../views/Logout.php">Log Out</a></li>
	</ul>
</div>

<?php 

include ('../models/user.php');
include ('../models/connection.php');

if(isset($_POST['submit']))
{
	$firstname =$_POST['firstname'];
 	$lastname = $_POST['lastname'];
 	$gender =$_POST['gender'];
 	$DOB = $_POST['DOB'];
 	$Address = $_POST['Address'];
 	$Phone = $_POST['Phone'];
 	$Email = $_POST['Email'];
 	$username = $_POST['username'];
 	$usertype = $_POST['usertype'];
 	$password = $_POST['password'];

  if (in_array($file_extension,$extension)) {
   
    $sql="insert into user_form (firstname, lastname, gender, DOB, address, phone, email, username, usertype, password, cpassword) values ('$firstname','$lastname','$gender','$DOB','$Address','$Phone','$Email','$username','$usertype','$password')";
    $result=mysqli_query($con,$sql);
    if ($result) {
      echo '<strong>Successfully</strong>';
    }
    else
    {
      die(mysqli_error($con));
    }


  }
}

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Profile</title>
	<style>
		body{
			margin: 0%;
			padding: 1%;
			background: black;
			color: white;
			font-size: 20px;
		}
		label{
			color: white;
			font-size: 20px;
			line-height: 40px;
			margin: auto;
  			width: 50%;
 			padding: 5px;
		}
	</style>
</head>

<body>
	<br>
	<h2 style="text-align:center;">Profile Information</h2>
	<br><br>
<fieldset>
<legend style="font-size: 20px; text-align: center;"><b>User Profile</b></legend>
<br>
<div style="text-align:center;">
  <table>
  <thead>
    
  </thead>
  <tbody>
  <?php 
	$sql="Select * from `user_form` order by id desc";
	$result=mysqli_query($con,$sql);
	$row=mysqli_fetch_assoc($result);
	$id=$row['id'];
	$firstname =$row['firstname'];
 	$lastname = $row['lastname'];
 	$gender =$row['gender'];
 	$DOB = $row['DOB'];
 	$Address = $row['address'];
 	$Phone = $row['phone'];
 	$Email = $row['email'];
 	$username = $row['username'];
 	$usertype = $row['usertype'];
 	$password = $row['password'];

echo '
      <tr><td>'."<label>First Name : </label><label> ".$firstname.'</label></td></tr>

      <tr><td>'."<label>Last Name : </label><label> ".$lastname.'</label></td></tr>

      <tr><td>'."<label>Gender : </label><label> ".$gender.'</label></td></tr>

      <tr><td>'."<label>Date of Birth: </label><label> ".$DOB.'</label></td></tr>

      <tr><td>'."<label>Address : </label><label> ".$Address.'</label></td></tr>

      <tr><td>'."<label>Phone : </label><label> ".$Phone.'</label></td></tr>

      <tr><td>'."<label>Email : </label><label> ".$Email.'</label></td></tr>

      <tr><td>'."<label>Username : </label><label> ".$username.'</label></td></tr>

      <tr><td>'."<label>Usertype : </label><label> ".$usertype.'</label></td></tr>';

      //<tr><td>'."<label>Password : </label><label> ".$password.'</label></td></tr>

 ?>
  
  </tbody>
</table>
</center>


<br><br>

</div>
</body>
</html>