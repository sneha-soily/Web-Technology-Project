

<?php
session_start();
	include "../models/connection.php";
	include "../models/function.php";


if($_SERVER['REQUEST_METHOD'] == "POST")
{
	$firstname =$_POST['firstname'];
 	$lastname = $_POST['lastname'];
 	$gender =$_POST['gender'];
 	$DOB = $_POST['DOB'];
 	$Address = $_POST['Address'];
 	$Phone = $_POST['Phone'];
 	$Email = $_POST['Email'];
 	$username = $_POST['username'];
 	$usertype = $_POST['usertype'];
 	$password = $_POST['password'];
 	$cfpassword = $_POST['cfpassword'];

		$query = "insert into user_form (firstname, lastname, gender, DOB, address, phone, email, username, usertype, password, cpassword) values ('$firstname','$lastname','$gender','$DOB','$Address','$Phone','$Email','$username','$usertype','$password','$cfpassword')";
 			mysqli_query($con,$query);
 			header("Location: ../views/Login.php");
 			die();

}
?>