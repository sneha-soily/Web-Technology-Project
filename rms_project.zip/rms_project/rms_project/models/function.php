<?php
function check_login($con)
{
	if(isset($_SESSION['username']))
	{
		$id = $_SESSION['username'];
		$query = "Select * from user_form where username = '$id' limit 1";

		$result = mysqli_query($con, $query);
		if($result && mysqli_num_rows($result)>0)
		{
			$user_data = mysqli_fetch_assoc($result);
			return $user_data;
		}
	}

	//redirect to lohin
	header("Location: ../views/Login.php");
	die;
}

?>
