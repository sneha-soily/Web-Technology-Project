<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "convertdb";

if (!$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname)) {
    die("failed to connect!");
}

function getConnection()
{
    global $dbhost;
    global $dbuser;
    global $dbpass;
    global $dbname;
    return $con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
}
